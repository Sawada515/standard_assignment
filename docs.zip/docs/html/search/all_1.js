var searchData=
[
  ['queue_5finstance_5ft_0',['queue_instance_t',['../structqueue__instance__t.html',1,'']]],
  ['queue_5ft_1',['queue_t',['../structqueue__t.html',1,'']]]
];
