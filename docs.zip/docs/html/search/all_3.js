var searchData=
[
  ['sensor_5fqueue_5ft_0',['sensor_queue_t',['../structsensor__queue__t.html',1,'']]]
];
